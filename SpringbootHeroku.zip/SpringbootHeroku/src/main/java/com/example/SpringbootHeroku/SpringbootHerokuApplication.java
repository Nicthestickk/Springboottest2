package com.example.SpringbootHeroku;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootHerokuApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootHerokuApplication.class, args);
	}

}
